import java.util.*;

public class App {
    public static void main(String[] args) {
        // Создаем компаратор для обратной сортировки (от большего к меньшему)
        Comparator<Integer> reverseComparator = Collections.reverseOrder();

        // Создаем TreeSet с использованием компаратора
        TreeSet<Integer> reverseTreeSet = new TreeSet<>(reverseComparator);

        // Добавляем элементы в множество
        reverseTreeSet.add(10);
        reverseTreeSet.add(5);
        reverseTreeSet.add(15);
        reverseTreeSet.add(3);
        reverseTreeSet.add(8);

        // Выводим элементы множества в консоль
        System.out.println("Элементы множества (в обратном порядке):");
        for (Integer element : reverseTreeSet) {
            System.out.println(element);
        }
    }
}
